package com.example.administrador.tp1;

import android.content.Intent;
import android.net.Uri;
import android.provider.ContactsContract;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    Contato contato = new Contato();

    Button buttonS;
    Button buttonWpp;
    Button buttonemail;
    EditText pegarnome;
    EditText pegartelefone;
    EditText pegaremail;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonS= (Button)findViewById(R.id.button1);
        buttonWpp = (Button)findViewById(R.id.buttonWpp);
        buttonemail = (Button)findViewById(R.id.buttonEmail);
        pegarnome =(EditText)findViewById(R.id.PegarNome);
        pegartelefone =(EditText)findViewById(R.id.PegarTelefone);
        pegaremail =(EditText)findViewById(R.id.PegarEmail);

        buttonS.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                contato.setNome(pegarnome.getText().toString());
                contato.setTelefone(pegartelefone.getText().toString());
                contato.setEmail(pegaremail.getText().toString());

                AppContato(contato.getNome(), contato.getTelefone(), contato.getEmail());

                Toast.makeText(getApplicationContext(), "VOCE CRIOU UM CONTATO", Toast.LENGTH_LONG).show();
            }
        });

        buttonWpp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                contato.setNome(pegarnome.getText().toString());
                contato.setTelefone(pegartelefone.getText().toString());
                contato.setEmail(pegaremail.getText().toString());

                Intent whatsApp = new Intent(Intent.ACTION_SEND);
                whatsApp.putExtra(Intent.EXTRA_TEXT, "Seu contato foi salvo!");
                whatsApp.setType("text/plain");
                whatsApp.putExtra("jid", contato.getTelefone()  + "@s.whatsapp.net");
                whatsApp.setPackage("com.whatsapp");

                startActivity(Intent.createChooser(whatsApp, ""));
                Toast.makeText(getApplicationContext(), "Mensagem enviada!", Toast.LENGTH_LONG).show();
            }
        });
        buttonemail.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                contato.setNome(pegarnome.getText().toString());
                contato.setTelefone(pegartelefone.getText().toString());
                contato.setEmail(pegaremail.getText().toString());

                Intent sendIntend = new Intent(Intent.ACTION_SENDTO, Uri.fromParts( "mailto", contato.getEmail(), null ) );
                sendIntend.putExtra(Intent.EXTRA_SUBJECT, "Seu contato foi salvo!");
                sendIntend.putExtra(Intent.EXTRA_TEXT, "Seu contato foi salvo por mim atravéz do meu aplicativo!");

                startActivity(Intent.createChooser(sendIntend, ""));

                Toast.makeText(getApplicationContext(), "Email enviado!", Toast.LENGTH_LONG).show();
            }
        });

    }



    public void AppContato(String nome, String telefone, String email){

        Intent appContact = new Intent(ContactsContract.Intents.Insert.ACTION);

        appContact.setType(ContactsContract.RawContacts.CONTENT_TYPE);

        appContact.putExtra(ContactsContract.Intents.Insert.NAME, nome );
        appContact.putExtra(ContactsContract.Intents.Insert.PHONE, telefone );
        appContact.putExtra(ContactsContract.Intents.Insert.EMAIL, email );

        startActivity(appContact);
    }



}
