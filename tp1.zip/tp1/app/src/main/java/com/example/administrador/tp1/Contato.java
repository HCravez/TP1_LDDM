package com.example.administrador.tp1;

public class Contato {

    private String Nome;
    private String Telefone;
    private String Email;

    Contato(){
        Nome = "";
        Telefone = "";
        Email = "";
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getEmail() {
        return Email;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getNome() {
        return Nome;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getTelefone() {
        return Telefone;
    }
}
